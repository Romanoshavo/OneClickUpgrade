# Check if the script is already running as admin
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if ($isAdmin) {
    Run-Script
} else {
    $scriptPath = $MyInvocation.MyCommand.Definition
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`""
    $psi = New-Object System.Diagnostics.ProcessStartInfo "powershell", $arguments
    $psi.Verb = "runas"
    
    try {
        $process = [System.Diagnostics.Process]::Start($psi)
        # Optionally, you can wait for the process to exit here
        #$process.WaitForExit()
    } catch {
        Write-Host "Failed to start PowerShell with elevated privileges. Please run the script as administrator."
    }
}

function Run-Script {
    Write-Host "Running with elevated privileges..."
    
    Write-Host "Creating System Restore Point..."
    try {
        $null = Invoke-CimMethod -Namespace root/default -ClassName SystemRestore -MethodName CreateRestorePoint -Arguments @{
            Description = "Pre-Winget Upgrade"
            EventType = 100
            RestorePointType = 12  # Use 12 for application install or uninstall
        }
        Write-Host "Restore Point Created."
    } catch {
        Write-Host "Failed to create a System Restore Point."
    }

    Write-Host "Running winget Upgrade..."
    winget upgrade --All
    Write-Host "Running winget Upgrade with include unknown software..."
    winget upgrade --include-unknown

    Write-Host "Running Upgrade...."
  
}

# Call the main function
Run-Script
Write-Host "Enjoy By RaisingDea Trademark 2024"
